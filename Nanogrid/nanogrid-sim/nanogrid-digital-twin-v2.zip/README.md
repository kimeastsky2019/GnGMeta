# NanoGrid Digital Twin Simulator

agent.gngmeta.com API 연동 및 인포그래픽 기반 에너지 시뮬레이터

## 🚀 주요 기능

### 1. 실시간 에너지 대시보드
- **agent.gngmeta.com/ds** API 연동으로 실시간 데이터 표시
- 인포그래픽 카드: 부하, PV 발전, 배터리 SoC, 그리드 수입/수출
- 시계열 차트: 24시간 전력 흐름 및 배터리 상태
- 에너지 자급률, 비용 절감, CO₂ 저감 지표

### 2. 고급 에너지 시뮬레이터
- **agent.gngmeta.com/sa** API로 시뮬레이션 결과 저장/조회
- 다중 데이터 소스:
  - API 실시간 데이터
  - CSV 파일 업로드
  - 합성 데이터 생성
- 3가지 시나리오 비교:
  - 기준선 (PV Only)
  - 현재 시스템
  - 최적화 시나리오
- 시뮬레이션 결과 히스토리 관리

### 3. 인포그래픽 컴포넌트
- MetricCard: 그라데이션 배경의 주요 지표 카드
- CircularGauge: 원형 게이지 (자급률 등)
- ProgressCard: 진행률 바
- ComparisonCard: 항목 비교 카드
- StatsGrid: 통계 그리드
- StatusCard: 상태 인디케이터
- TimelineCard: 타임라인 (추후 확장 가능)

## 📁 프로젝트 구조

```
src/
├── components/
│   ├── Infographic.jsx       # 인포그래픽 컴포넌트들
│   ├── KPIGrid.jsx           # KPI 표시 그리드
│   └── TimeseriesChart.jsx   # Recharts 기반 시계열 차트
├── pages/
│   ├── AppLayout.jsx         # 앱 레이아웃 (네비게이션)
│   ├── Dashboard.jsx         # 실시간 대시보드
│   └── SimulatorEnhanced.jsx # API 연동 시뮬레이터
├── lib/
│   ├── api.js               # agent.gngmeta.com API 서비스
│   └── storage.js           # LocalStorage 유틸리티
└── main.jsx                 # 앱 진입점
```

## 🔌 API 엔드포인트

### Digital System API (DS)
- `GET /ds/load` - 실시간 부하 데이터
- `GET /ds/pv` - PV 발전 데이터
- `GET /ds/battery` - 배터리 상태
- `GET /ds/energy` - 통합 에너지 데이터
- `GET /ds/sites` - 사이트 목록

### System Analysis API (SA)
- `POST /sa/simulate` - 시뮬레이션 실행
- `POST /sa/compare` - 시나리오 비교
- `POST /sa/optimize` - 최적화 추천
- `POST /sa/analyze` - KPI 분석
- `POST /sa/results` - 결과 저장
- `GET /sa/results` - 결과 조회

## 🛠️ 설치 및 실행

```bash
# 의존성 설치
npm install

# 개발 서버 실행
npm run dev

# 프로덕션 빌드
npm run build

# 빌드 결과 미리보기
npm run preview
```

## 💡 사용 방법

### 대시보드
1. 홈페이지 접속 시 실시간 대시보드 표시
2. 30초마다 자동 업데이트
3. 사이트 선택으로 다른 시스템 모니터링
4. "새로고침" 버튼으로 수동 업데이트

### 시뮬레이터
1. 상단 메뉴에서 "시뮬레이터" 선택
2. 데이터 소스 선택:
   - "API에서 실시간 데이터 가져오기": agent.gngmeta.com/ds API 연동
   - "CSV 파일 업로드": 로컬 CSV 파일 사용
   - "합성 데이터 사용": 자동 생성된 패턴 데이터
3. 파라미터 조정 (선택사항)
4. 시나리오 자동 비교 및 KPI 확인
5. "결과 저장" 버튼으로 API에 저장
6. "다운로드" 버튼으로 CSV/JSON/PNG 내보내기

## 🎨 주요 개선사항

### v0.2.0 (현재 버전)
- ✅ agent.gngmeta.com API 완전 연동
- ✅ 인포그래픽 기반 UI 재설계
- ✅ 실시간 대시보드 추가
- ✅ 다중 데이터 소스 지원
- ✅ 시뮬레이션 결과 클라우드 저장
- ✅ 반응형 디자인 개선
- ✅ 다크모드 지원 준비

## 🔧 기술 스택

- **React 18** - UI 프레임워크
- **Vite** - 빌드 도구
- **React Router** - 라우팅
- **Recharts** - 차트 라이브러리
- **Tailwind CSS** - 스타일링
- **PapaCSV** - CSV 파싱
- **html2canvas** - 차트 캡처

## 📊 시뮬레이션 엔진

### 에너지 매칭 알고리즘
1. 직접 소비: 부하와 PV의 직접 매칭
2. 배터리 충전: 잉여 PV → 배터리
3. 배터리 방전: 배터리 → 부하
4. 그리드 수입: 부족분 그리드에서 충당
5. 그리드 수출: 잉여 전력 판매

### 계산 KPI
- 총 수요량 (kWh)
- 현장 발전량 (kWh)
- 현장 사용량 (kWh)
- 수입/수출 전력량 (kWh)
- 매칭률 / 자급률
- 자가소비율
- 비용 (수입 - 수출)
- CO₂ 배출량 (kg)

## 🚀 향후 계획

- [ ] 웹소켓 기반 실시간 업데이트
- [ ] 알림 및 이벤트 로깅
- [ ] 사용자 인증 및 권한 관리
- [ ] 다중 사이트 동시 모니터링
- [ ] AI 기반 최적화 추천
- [ ] 모바일 앱 지원

## 📝 라이선스

GnG International © 2024

## 👥 개발자

Dongho Kim - CEO, GnG International
