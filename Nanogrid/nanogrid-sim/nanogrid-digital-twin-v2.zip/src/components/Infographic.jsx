import React from 'react'

// 메트릭 카드 - 숫자 강조형
export function MetricCard({ title, value, unit, change, icon, color = 'blue' }) {
  const colorClasses = {
    blue: 'from-blue-500 to-blue-600',
    green: 'from-green-500 to-green-600',
    orange: 'from-orange-500 to-orange-600',
    purple: 'from-purple-500 to-purple-600',
    red: 'from-red-500 to-red-600',
    teal: 'from-teal-500 to-teal-600',
  }

  return (
    <div className={`relative overflow-hidden rounded-2xl bg-gradient-to-br ${colorClasses[color]} p-6 text-white shadow-lg`}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="text-sm font-medium opacity-90">{title}</div>
          <div className="mt-2 flex items-baseline gap-2">
            <div className="text-4xl font-bold">{value}</div>
            {unit && <div className="text-lg opacity-80">{unit}</div>}
          </div>
          {change && (
            <div className={`mt-2 text-sm ${change >= 0 ? 'text-green-100' : 'text-red-100'}`}>
              {change >= 0 ? '↑' : '↓'} {Math.abs(change)}%
            </div>
          )}
        </div>
        {icon && (
          <div className="text-5xl opacity-20">{icon}</div>
        )}
      </div>
    </div>
  )
}

// 진행률 카드
export function ProgressCard({ title, value, max, unit, color = 'blue' }) {
  const percentage = max > 0 ? (value / max) * 100 : 0
  
  const colorClasses = {
    blue: 'bg-blue-500',
    green: 'bg-green-500',
    orange: 'bg-orange-500',
    purple: 'bg-purple-500',
  }

  return (
    <div className="rounded-2xl border bg-white p-6 shadow-soft dark:bg-gray-900 dark:border-gray-800">
      <div className="flex items-center justify-between mb-3">
        <div className="font-semibold">{title}</div>
        <div className="text-sm text-gray-500">
          {value.toFixed(1)} / {max.toFixed(1)} {unit}
        </div>
      </div>
      <div className="relative h-3 bg-gray-200 rounded-full overflow-hidden dark:bg-gray-700">
        <div 
          className={`h-full ${colorClasses[color]} transition-all duration-500 rounded-full`}
          style={{ width: `${Math.min(percentage, 100)}%` }}
        />
      </div>
      <div className="mt-2 text-right text-sm font-medium text-gray-600 dark:text-gray-400">
        {percentage.toFixed(1)}%
      </div>
    </div>
  )
}

// 비교 카드
export function ComparisonCard({ title, items }) {
  return (
    <div className="rounded-2xl border bg-white p-6 shadow-soft dark:bg-gray-900 dark:border-gray-800">
      <div className="font-semibold mb-4">{title}</div>
      <div className="space-y-4">
        {items.map((item, idx) => (
          <div key={idx} className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full ${item.color || 'bg-blue-500'}`} />
              <span className="text-sm">{item.label}</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-lg font-bold">{item.value}</span>
              <span className="text-xs text-gray-500">{item.unit}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// 상태 인디케이터 카드
export function StatusCard({ title, status, message, icon }) {
  const statusStyles = {
    success: { bg: 'bg-green-50 dark:bg-green-900/20', border: 'border-green-200 dark:border-green-800', text: 'text-green-700 dark:text-green-300' },
    warning: { bg: 'bg-yellow-50 dark:bg-yellow-900/20', border: 'border-yellow-200 dark:border-yellow-800', text: 'text-yellow-700 dark:text-yellow-300' },
    error: { bg: 'bg-red-50 dark:bg-red-900/20', border: 'border-red-200 dark:border-red-800', text: 'text-red-700 dark:text-red-300' },
    info: { bg: 'bg-blue-50 dark:bg-blue-900/20', border: 'border-blue-200 dark:border-blue-800', text: 'text-blue-700 dark:text-blue-300' },
  }

  const style = statusStyles[status] || statusStyles.info

  return (
    <div className={`rounded-2xl border ${style.border} ${style.bg} p-6 shadow-soft`}>
      <div className="flex items-start gap-4">
        {icon && (
          <div className={`text-3xl ${style.text}`}>{icon}</div>
        )}
        <div className="flex-1">
          <div className={`font-semibold ${style.text} mb-1`}>{title}</div>
          <div className="text-sm text-gray-600 dark:text-gray-400">{message}</div>
        </div>
      </div>
    </div>
  )
}

// 통계 그리드
export function StatsGrid({ stats }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {stats.map((stat, idx) => (
        <div key={idx} className="rounded-xl border bg-white p-4 shadow-soft dark:bg-gray-900 dark:border-gray-800">
          <div className="text-xs text-gray-500 dark:text-gray-400 uppercase mb-1">{stat.label}</div>
          <div className="flex items-baseline gap-1">
            <div className="text-2xl font-bold">{stat.value}</div>
            <div className="text-sm text-gray-500">{stat.unit}</div>
          </div>
          {stat.trend && (
            <div className={`text-xs mt-1 ${stat.trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
              {stat.trend > 0 ? '↑' : '↓'} {Math.abs(stat.trend)}%
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

// 원형 게이지
export function CircularGauge({ title, value, max, unit, color = 'blue' }) {
  const percentage = max > 0 ? (value / max) * 100 : 0
  const circumference = 2 * Math.PI * 45
  const strokeDashoffset = circumference - (percentage / 100) * circumference

  const colorClasses = {
    blue: 'stroke-blue-500',
    green: 'stroke-green-500',
    orange: 'stroke-orange-500',
    purple: 'stroke-purple-500',
    red: 'stroke-red-500',
  }

  return (
    <div className="rounded-2xl border bg-white p-6 shadow-soft dark:bg-gray-900 dark:border-gray-800 flex flex-col items-center">
      <div className="text-sm font-medium mb-4">{title}</div>
      <div className="relative w-32 h-32">
        <svg className="w-full h-full transform -rotate-90">
          <circle
            cx="64"
            cy="64"
            r="45"
            stroke="currentColor"
            strokeWidth="8"
            fill="none"
            className="text-gray-200 dark:text-gray-700"
          />
          <circle
            cx="64"
            cy="64"
            r="45"
            strokeWidth="8"
            fill="none"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className={`${colorClasses[color]} transition-all duration-500`}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="text-2xl font-bold">{value.toFixed(1)}</div>
          <div className="text-xs text-gray-500">{unit}</div>
        </div>
      </div>
      <div className="mt-4 text-sm text-gray-500">
        {percentage.toFixed(0)}% of {max.toFixed(1)} {unit}
      </div>
    </div>
  )
}

// 타임라인 카드
export function TimelineCard({ title, events }) {
  return (
    <div className="rounded-2xl border bg-white p-6 shadow-soft dark:bg-gray-900 dark:border-gray-800">
      <div className="font-semibold mb-4">{title}</div>
      <div className="space-y-4">
        {events.map((event, idx) => (
          <div key={idx} className="flex gap-4">
            <div className="flex flex-col items-center">
              <div className={`w-3 h-3 rounded-full ${event.color || 'bg-blue-500'}`} />
              {idx < events.length - 1 && (
                <div className="flex-1 w-0.5 bg-gray-200 dark:bg-gray-700 my-1" style={{ minHeight: '20px' }} />
              )}
            </div>
            <div className="flex-1 pb-4">
              <div className="text-sm font-medium">{event.title}</div>
              <div className="text-xs text-gray-500 mt-1">{event.time}</div>
              {event.description && (
                <div className="text-sm text-gray-600 dark:text-gray-400 mt-2">{event.description}</div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
