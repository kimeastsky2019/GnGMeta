import React from 'react'

// 원형 프로그레스 게이지
export function CircularGauge({ value, max = 100, label, unit = '%', color = 'blue' }) {
  const percentage = Math.min(100, (value / max) * 100)
  const circumference = 2 * Math.PI * 40
  const strokeDashoffset = circumference - (percentage / 100) * circumference

  const colorClasses = {
    blue: 'stroke-blue-500',
    green: 'stroke-green-500',
    yellow: 'stroke-yellow-500',
    red: 'stroke-red-500',
    purple: 'stroke-purple-500',
  }

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-28 h-28">
        <svg className="transform -rotate-90 w-28 h-28">
          <circle
            cx="56"
            cy="56"
            r="40"
            stroke="currentColor"
            strokeWidth="8"
            fill="none"
            className="text-gray-200 dark:text-gray-700"
          />
          <circle
            cx="56"
            cy="56"
            r="40"
            stroke="currentColor"
            strokeWidth="8"
            fill="none"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            className={colorClasses[color] || colorClasses.blue}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <div className="text-lg font-bold">{value.toFixed(1)}</div>
            <div className="text-xs text-gray-500">{unit}</div>
          </div>
        </div>
      </div>
      {label && <div className="mt-2 text-sm text-center text-gray-600">{label}</div>}
    </div>
  )
}

// 수평 바 게이지
export function HorizontalBar({ label, value, max, unit = 'kWh', color = 'blue' }) {
  const percentage = Math.min(100, (value / max) * 100)
  
  const colorClasses = {
    blue: 'bg-blue-500',
    green: 'bg-green-500',
    yellow: 'bg-yellow-500',
    red: 'bg-red-500',
    purple: 'bg-purple-500',
  }

  return (
    <div className="space-y-1">
      <div className="flex justify-between text-sm">
        <span className="text-gray-600">{label}</span>
        <span className="font-semibold">{value.toFixed(1)} {unit}</span>
      </div>
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
        <div
          className={`h-3 rounded-full ${colorClasses[color] || colorClasses.blue}`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  )
}

// 스탯 카드
export function StatCard({ icon, label, value, unit, trend, color = 'blue' }) {
  const colorClasses = {
    blue: 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400',
    green: 'bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400',
    yellow: 'bg-yellow-50 dark:bg-yellow-900/20 text-yellow-600 dark:text-yellow-400',
    red: 'bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400',
    purple: 'bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400',
  }

  return (
    <div className="border rounded-2xl p-4 shadow-soft hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div className={`p-2 rounded-xl ${colorClasses[color]}`}>
          {icon}
        </div>
        {trend && (
          <div className={`text-xs px-2 py-1 rounded-lg ${trend > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
            {trend > 0 ? '↑' : '↓'} {Math.abs(trend)}%
          </div>
        )}
      </div>
      <div className="mt-3">
        <div className="text-2xl font-bold">{value}</div>
        <div className="text-xs text-gray-500 mt-1">{unit}</div>
        <div className="text-sm text-gray-600 mt-1">{label}</div>
      </div>
    </div>
  )
}

// 비교 카드
export function ComparisonCard({ title, items }) {
  return (
    <div className="border rounded-2xl p-4 shadow-soft">
      <h4 className="font-semibold mb-3">{title}</h4>
      <div className="space-y-3">
        {items.map((item, idx) => (
          <div key={idx} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${item.color}`} />
              <span className="text-sm">{item.label}</span>
            </div>
            <div className="text-right">
              <div className="font-semibold">{item.value}</div>
              <div className="text-xs text-gray-500">{item.unit}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// 에너지 플로우 다이어그램
export function EnergyFlow({ pv, load, battery, grid }) {
  return (
    <div className="border rounded-2xl p-6 shadow-soft">
      <h4 className="font-semibold mb-4">에너지 흐름</h4>
      <div className="flex items-center justify-between gap-4">
        {/* PV */}
        <div className="flex-1 text-center">
          <div className="w-16 h-16 mx-auto bg-yellow-100 dark:bg-yellow-900/20 rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
          </div>
          <div className="mt-2 text-sm font-semibold">태양광</div>
          <div className="text-lg font-bold text-yellow-600">{pv.toFixed(1)}</div>
          <div className="text-xs text-gray-500">kW</div>
        </div>

        {/* Arrow */}
        <div className="text-gray-400">→</div>

        {/* Battery */}
        <div className="flex-1 text-center">
          <div className="w-16 h-16 mx-auto bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
            </svg>
          </div>
          <div className="mt-2 text-sm font-semibold">배터리</div>
          <div className="text-lg font-bold text-green-600">{battery.toFixed(1)}</div>
          <div className="text-xs text-gray-500">kWh</div>
        </div>

        {/* Arrow */}
        <div className="text-gray-400">→</div>

        {/* Load */}
        <div className="flex-1 text-center">
          <div className="w-16 h-16 mx-auto bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <div className="mt-2 text-sm font-semibold">부하</div>
          <div className="text-lg font-bold text-blue-600">{load.toFixed(1)}</div>
          <div className="text-xs text-gray-500">kW</div>
        </div>

        {/* Grid */}
        <div className="flex-1 text-center">
          <div className="w-16 h-16 mx-auto bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4" />
            </svg>
          </div>
          <div className="mt-2 text-sm font-semibold">계통</div>
          <div className="text-lg font-bold text-purple-600">{grid.toFixed(1)}</div>
          <div className="text-xs text-gray-500">kW</div>
        </div>
      </div>
    </div>
  )
}

// 타임라인 표시
export function Timeline({ events }) {
  return (
    <div className="border rounded-2xl p-4 shadow-soft">
      <h4 className="font-semibold mb-3">시뮬레이션 이벤트</h4>
      <div className="space-y-3">
        {events.map((event, idx) => (
          <div key={idx} className="flex gap-3">
            <div className="flex flex-col items-center">
              <div className={`w-3 h-3 rounded-full ${event.type === 'peak' ? 'bg-red-500' : event.type === 'charge' ? 'bg-green-500' : 'bg-blue-500'}`} />
              {idx < events.length - 1 && <div className="w-0.5 flex-1 bg-gray-300 mt-1" />}
            </div>
            <div className="pb-3">
              <div className="text-sm font-medium">{event.title}</div>
              <div className="text-xs text-gray-500">{event.time}</div>
              <div className="text-xs text-gray-600 mt-1">{event.description}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// 스피드미터
export function Speedometer({ value, max, label, thresholds = { low: 30, medium: 70 } }) {
  const percentage = Math.min(100, (value / max) * 100)
  const rotation = (percentage / 100) * 180 - 90

  let color = 'text-red-500'
  if (percentage < thresholds.low) color = 'text-green-500'
  else if (percentage < thresholds.medium) color = 'text-yellow-500'

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-40 h-20 overflow-hidden">
        <svg viewBox="0 0 200 100" className="w-full h-full">
          {/* Background arc */}
          <path
            d="M 20 90 A 80 80 0 0 1 180 90"
            fill="none"
            stroke="currentColor"
            strokeWidth="12"
            className="text-gray-200 dark:text-gray-700"
          />
          {/* Active arc */}
          <path
            d="M 20 90 A 80 80 0 0 1 180 90"
            fill="none"
            stroke="currentColor"
            strokeWidth="12"
            strokeDasharray={`${(percentage / 100) * 251.2} 251.2`}
            className={color}
          />
          {/* Needle */}
          <line
            x1="100"
            y1="90"
            x2="100"
            y2="30"
            stroke="currentColor"
            strokeWidth="3"
            className="text-gray-700 dark:text-gray-300"
            transform={`rotate(${rotation}, 100, 90)`}
          />
          <circle cx="100" cy="90" r="6" className="fill-gray-700 dark:fill-gray-300" />
        </svg>
        <div className="absolute inset-0 flex items-end justify-center pb-2">
          <div className="text-center">
            <div className="text-xl font-bold">{value.toFixed(1)}</div>
            <div className="text-xs text-gray-500">/ {max}</div>
          </div>
        </div>
      </div>
      {label && <div className="mt-1 text-sm text-gray-600">{label}</div>}
    </div>
  )
}

// 실시간 상태 인디케이터
export function StatusIndicator({ status, label }) {
  const statusConfig = {
    online: { color: 'bg-green-500', text: '정상', pulse: true },
    warning: { color: 'bg-yellow-500', text: '경고', pulse: true },
    offline: { color: 'bg-red-500', text: '오프라인', pulse: false },
    idle: { color: 'bg-gray-400', text: '대기', pulse: false },
  }

  const config = statusConfig[status] || statusConfig.idle

  return (
    <div className="flex items-center gap-2">
      <div className="relative">
        <div className={`w-3 h-3 rounded-full ${config.color}`} />
        {config.pulse && (
          <div className={`absolute inset-0 rounded-full ${config.color} animate-ping opacity-75`} />
        )}
      </div>
      <div className="text-sm">
        <span className="font-medium">{label}</span>
        <span className="text-gray-500 ml-1">• {config.text}</span>
      </div>
    </div>
  )
}
