import React from 'react'

// KPI 메타데이터 정의
const KPI_META = {
  demand_kwh: { label: '총 수요', unit: 'kWh', icon: '⚡', color: 'text-blue-600' },
  onsite_gen_kwh: { label: '태양광 발전', unit: 'kWh', icon: '☀️', color: 'text-yellow-600' },
  onsite_used_kwh: { label: '현장 사용', unit: 'kWh', icon: '🔋', color: 'text-green-600' },
  import_kwh: { label: '계통 수입', unit: 'kWh', icon: '⬇️', color: 'text-purple-600' },
  export_kwh: { label: '계통 수출', unit: 'kWh', icon: '⬆️', color: 'text-teal-600' },
  discharge_kwh: { label: '배터리 방전', unit: 'kWh', icon: '🔌', color: 'text-orange-600' },
  match_rate: { label: '매칭률', unit: '%', icon: '🎯', color: 'text-blue-600', isPercent: true },
  self_consumption: { label: '자가소비율', unit: '%', icon: '♻️', color: 'text-green-600', isPercent: true },
  self_sufficiency: { label: '자급률', unit: '%', icon: '🏠', color: 'text-indigo-600', isPercent: true },
  curtail_ratio: { label: '커튼 비율', unit: '%', icon: '✂️', color: 'text-red-600', isPercent: true },
  cost_import_krw: { label: '수입 비용', unit: '₩', icon: '💵', color: 'text-red-600' },
  revenue_export_krw: { label: '수출 수익', unit: '₩', icon: '💰', color: 'text-green-600' },
  net_cost_krw: { label: '순 비용', unit: '₩', icon: '💳', color: 'text-purple-600' },
  emissions_kg: { label: 'CO₂ 배출', unit: 'kg', icon: '🌍', color: 'text-gray-600' },
}

export default function KPIGrid({ kpi = {}, compact = false }) {
  if (!kpi || Object.keys(kpi).length === 0) {
    return <div className="text-sm text-gray-500">KPI가 없습니다.</div>
  }

  const formatValue = (key, val) => {
    const meta = KPI_META[key]
    if (typeof val !== 'number') return String(val)
    
    if (meta?.isPercent) {
      return (val * 100).toFixed(1)
    }
    
    if (key.includes('cost') || key.includes('revenue')) {
      return val.toLocaleString('ko-KR', { maximumFractionDigits: 0 })
    }
    
    return val.toFixed(2)
  }

  if (compact) {
    return (
      <div className="grid grid-cols-2 gap-2">
        {Object.entries(kpi).slice(0, 4).map(([key, val]) => {
          const meta = KPI_META[key] || { label: key, unit: '', color: 'text-gray-600' }
          return (
            <div key={key} className="text-center">
              <div className="text-xs text-gray-500">{meta.label}</div>
              <div className={`text-lg font-bold ${meta.color}`}>
                {formatValue(key, val)}
                <span className="text-xs ml-1">{meta.unit}</span>
              </div>
            </div>
          )
        })}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 gap-3">
      {Object.entries(kpi).map(([key, val]) => {
        const meta = KPI_META[key] || { 
          label: key.replace(/_/g, ' ').toUpperCase(), 
          unit: '', 
          icon: '📊',
          color: 'text-gray-600' 
        }
        
        return (
          <div key={key} className="bg-gray-50 dark:bg-gray-800 rounded-xl p-3">
            <div className="flex items-start justify-between mb-1">
              <div className="text-xs text-gray-500">{meta.label}</div>
              <span className="text-lg">{meta.icon}</span>
            </div>
            <div className={`text-xl font-bold ${meta.color}`}>
              {meta.unit === '₩' && meta.unit}
              {formatValue(key, val)}
              {meta.unit !== '₩' && <span className="text-sm ml-1 text-gray-500">{meta.unit}</span>}
            </div>
          </div>
        )
      })}
    </div>
  )
}
