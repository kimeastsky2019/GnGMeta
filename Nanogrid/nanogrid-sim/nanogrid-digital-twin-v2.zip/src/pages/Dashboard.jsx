import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api, createTimeRange, handleApiError } from '../lib/api'
import { 
  MetricCard, 
  ProgressCard, 
  ComparisonCard, 
  StatusCard,
  StatsGrid,
  CircularGauge,
  TimelineCard 
} from '../components/Infographic'
import TimeseriesChart from '../components/TimeseriesChart'

export default function Dashboard() {
  const [loading, setLoading] = useState(true)
  const [realTimeData, setRealTimeData] = useState(null)
  const [energyData, setEnergyData] = useState(null)
  const [sites, setSites] = useState([])
  const [selectedSite, setSelectedSite] = useState(null)
  const [lastUpdate, setLastUpdate] = useState(new Date())

  // 실시간 데이터 로드
  useEffect(() => {
    loadDashboardData()
    const interval = setInterval(loadDashboardData, 30000) // 30초마다 업데이트
    return () => clearInterval(interval)
  }, [selectedSite])

  const loadDashboardData = async () => {
    try {
      setLoading(true)
      
      // 사이트 목록 로드
      const sitesData = await api.ds.getSites().catch(() => ({ sites: [] }))
      if (sitesData.sites && sitesData.sites.length > 0) {
        setSites(sitesData.sites)
        if (!selectedSite) setSelectedSite(sitesData.sites[0].id)
      }

      const timeRange = createTimeRange(24)
      const siteId = selectedSite

      // 병렬로 데이터 로드
      const [loadData, pvData, batteryData, energyData] = await Promise.all([
        api.ds.getLoadData({ ...timeRange, siteId }).catch(() => null),
        api.ds.getPVData({ ...timeRange, siteId }).catch(() => null),
        api.ds.getBatteryData({ ...timeRange, siteId }).catch(() => null),
        api.ds.getEnergyData({ ...timeRange, siteId }).catch(() => null),
      ])

      setRealTimeData({
        load: loadData,
        pv: pvData,
        battery: batteryData,
      })
      
      setEnergyData(energyData)
      setLastUpdate(new Date())
    } catch (error) {
      console.error('Dashboard data load error:', error)
    } finally {
      setLoading(false)
    }
  }

  // 현재 시스템 상태 계산
  const currentMetrics = React.useMemo(() => {
    if (!realTimeData || !energyData) {
      return {
        currentLoad: 0,
        currentPV: 0,
        batterySoC: 0,
        gridImport: 0,
        selfSufficiency: 0,
        costSavings: 0,
      }
    }

    // 최신 데이터 포인트에서 값 추출
    const latestLoad = realTimeData.load?.data?.[realTimeData.load.data.length - 1] || {}
    const latestPV = realTimeData.pv?.data?.[realTimeData.pv.data.length - 1] || {}
    const latestBattery = realTimeData.battery?.data?.[realTimeData.battery.data.length - 1] || {}
    
    return {
      currentLoad: latestLoad.value || 0,
      currentPV: latestPV.value || 0,
      batterySoC: latestBattery.soc || 0,
      batteryPower: latestBattery.power || 0,
      gridImport: Math.max(0, (latestLoad.value || 0) - (latestPV.value || 0) - (latestBattery.power || 0)),
      selfSufficiency: energyData?.kpi?.self_sufficiency || 0,
      costSavings: energyData?.kpi?.cost_savings || 0,
      co2Reduction: energyData?.kpi?.co2_reduction || 0,
    }
  }, [realTimeData, energyData])

  // 차트용 데이터 변환
  const chartData = React.useMemo(() => {
    if (!realTimeData) return []
    
    const maxLength = Math.max(
      realTimeData.load?.data?.length || 0,
      realTimeData.pv?.data?.length || 0,
      realTimeData.battery?.data?.length || 0
    )

    return Array.from({ length: maxLength }, (_, i) => ({
      ts: i,
      load: realTimeData.load?.data?.[i]?.value || 0,
      pv: realTimeData.pv?.data?.[i]?.value || 0,
      battery: realTimeData.battery?.data?.[i]?.power || 0,
      soc: realTimeData.battery?.data?.[i]?.soc || 0,
    }))
  }, [realTimeData])

  if (loading && !realTimeData) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
          <div className="mt-4 text-gray-600">데이터 로딩 중...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">실시간 에너지 대시보드</h2>
          <p className="text-sm text-gray-500 mt-1">
            마지막 업데이트: {lastUpdate.toLocaleTimeString('ko-KR')}
          </p>
        </div>
        <div className="flex gap-3">
          <select 
            className="px-4 py-2 border rounded-xl bg-white dark:bg-gray-800"
            value={selectedSite || ''}
            onChange={(e) => setSelectedSite(e.target.value)}
          >
            {sites.length === 0 ? (
              <option>사이트 없음</option>
            ) : (
              sites.map(site => (
                <option key={site.id} value={site.id}>{site.name}</option>
              ))
            )}
          </select>
          <button 
            onClick={loadDashboardData}
            className="px-4 py-2 rounded-xl bg-blue-500 text-white hover:bg-blue-600 transition-colors"
          >
            새로고침
          </button>
          <Link 
            to="/sim"
            className="px-4 py-2 rounded-xl bg-black text-white hover:bg-gray-800 transition-colors"
          >
            시뮬레이터
          </Link>
        </div>
      </div>

      {/* 상태 카드 */}
      <StatusCard
        title="시스템 정상 작동 중"
        status="success"
        message="모든 에너지 시스템이 정상적으로 운영되고 있습니다."
        icon="✓"
      />

      {/* 주요 메트릭 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="현재 부하"
          value={currentMetrics.currentLoad.toFixed(1)}
          unit="kW"
          icon="⚡"
          color="blue"
        />
        <MetricCard
          title="PV 발전"
          value={currentMetrics.currentPV.toFixed(1)}
          unit="kW"
          icon="☀️"
          color="orange"
        />
        <MetricCard
          title="배터리 SoC"
          value={currentMetrics.batterySoC.toFixed(0)}
          unit="%"
          icon="🔋"
          color="green"
        />
        <MetricCard
          title="그리드 수입"
          value={currentMetrics.gridImport.toFixed(1)}
          unit="kW"
          icon="🔌"
          color="purple"
        />
      </div>

      {/* 자급률 및 절감액 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <CircularGauge
          title="에너지 자급률"
          value={currentMetrics.selfSufficiency * 100}
          max={100}
          unit="%"
          color="green"
        />
        <div className="md:col-span-2">
          <ComparisonCard
            title="오늘의 성과"
            items={[
              { 
                label: '비용 절감', 
                value: currentMetrics.costSavings.toFixed(0), 
                unit: '원',
                color: 'bg-green-500' 
              },
              { 
                label: 'CO₂ 저감', 
                value: currentMetrics.co2Reduction.toFixed(1), 
                unit: 'kg',
                color: 'bg-blue-500' 
              },
              { 
                label: '자가소비율', 
                value: (currentMetrics.selfSufficiency * 100).toFixed(1), 
                unit: '%',
                color: 'bg-purple-500' 
              },
            ]}
          />
        </div>
      </div>

      {/* 통계 그리드 */}
      <StatsGrid
        stats={[
          { label: '일일 발전량', value: (energyData?.daily_generation || 0).toFixed(0), unit: 'kWh' },
          { label: '일일 소비량', value: (energyData?.daily_consumption || 0).toFixed(0), unit: 'kWh' },
          { label: '피크 부하', value: (energyData?.peak_load || 0).toFixed(1), unit: 'kW' },
          { label: '평균 부하', value: (energyData?.avg_load || 0).toFixed(1), unit: 'kW' },
        ]}
      />

      {/* 시계열 차트 */}
      <div className="grid md:grid-cols-2 gap-4">
        <div className="rounded-2xl border bg-white p-6 shadow-soft dark:bg-gray-900 dark:border-gray-800">
          <h3 className="font-semibold mb-4">실시간 전력 흐름 (24시간)</h3>
          <TimeseriesChart
            data={chartData}
            series={[
              { dataKey: 'load', name: '부하', stroke: '#3b82f6' },
              { dataKey: 'pv', name: 'PV', stroke: '#f59e0b' },
              { dataKey: 'battery', name: '배터리', stroke: '#10b981' },
            ]}
          />
        </div>
        <div className="rounded-2xl border bg-white p-6 shadow-soft dark:bg-gray-900 dark:border-gray-800">
          <h3 className="font-semibold mb-4">배터리 SoC (24시간)</h3>
          <TimeseriesChart
            data={chartData}
            series={[
              { dataKey: 'soc', name: 'SoC', stroke: '#8b5cf6' },
            ]}
          />
        </div>
      </div>

      {/* 진행률 카드들 */}
      <div className="grid md:grid-cols-2 gap-4">
        <ProgressCard
          title="일일 발전 목표"
          value={energyData?.daily_generation || 0}
          max={energyData?.daily_target || 1000}
          unit="kWh"
          color="orange"
        />
        <ProgressCard
          title="배터리 용량"
          value={currentMetrics.batterySoC}
          max={100}
          unit="%"
          color="green"
        />
      </div>

      {/* 시뮬레이션 CTA */}
      <div className="rounded-2xl border border-dashed border-gray-300 dark:border-gray-700 p-8 text-center">
        <h3 className="text-lg font-semibold mb-2">에너지 시스템 최적화</h3>
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
          시뮬레이터에서 다양한 시나리오를 비교하고 최적의 에너지 전략을 수립하세요.
        </p>
        <Link 
          to="/sim"
          className="inline-block px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600 text-white font-medium hover:shadow-lg transition-all"
        >
          시뮬레이터 실행하기 →
        </Link>
      </div>
    </div>
  )
}
