
import React, { useEffect, useMemo, useRef, useState } from 'react'
import KPIGrid from '../components/KPIGrid'
import TimeseriesChart from '../components/TimeseriesChart'
import Papa from 'papaparse'
import html2canvas from 'html2canvas'
import { saveJSON, loadJSON, downloadBlob, toCSV } from '../lib/storage'
import { api, handleApiError, createTimeRange } from '../lib/api'
import { 
  CircularGauge, 
  StatCard, 
  ComparisonCard, 
  Timeline,
  HorizontalBar 
} from '../components/Infographics'

const clamp = (v, a, b) => Math.max(a, Math.min(b, v))
const toFixed = (n) => (typeof n === 'number' ? Number(n.toFixed(3)) : n)

const LS_KEY = 'ng.sim.params.v1'
const LS_DEMAND = 'ng.sim.demand.v1'

export default function Simulator() {
  const [params, setParams] = useState(() => loadJSON(LS_KEY, {
    horizonHours: 24 * 7,
    stepMinutes: 15,
    loadBaseKw: 80,
    loadMorningPeakKw: 30,
    loadEveningPeakKw: 40,
    loadNoisePct: 5,
    pvKwDc: 120,
    pvWeatherPct: 15,
    battCapacityKwh: 300,
    battPchgKw: 100,
    battPdisKw: 100,
    battRtEff: 92,
    battSocMinPct: 10,
    battSocMaxPct: 90,
    peakStart: 9, peakEnd: 12, peak2Start: 18, peak2End: 21,
    pricePeak: 220, priceOff: 110, feedin: 60, co2_g_per_kwh: 450,
  }))
  useEffect(()=> saveJSON(LS_KEY, params), [params])

  const [demandCSV, setDemandCSV] = useState(()=> loadJSON(LS_DEMAND, null))
  useEffect(()=> saveJSON(LS_DEMAND, demandCSV), [demandCSV])

  // API 연동 상태
  const [useRealData, setUseRealData] = useState(false)
  const [loading, setLoading] = useState(false)
  const [apiError, setApiError] = useState(null)
  const [sites, setSites] = useState([])
  const [selectedSite, setSelectedSite] = useState(null)

  // 사이트 목록 로드
  useEffect(() => {
    loadSites()
  }, [])

  const loadSites = async () => {
    try {
      const data = await api.ds.getSites()
      setSites(data.sites || [])
      if (data.sites?.length > 0) {
        setSelectedSite(data.sites[0].id)
      }
    } catch (err) {
      console.error('Failed to load sites:', err)
      setSites([{ id: 'demo', name: 'Demo Site' }])
      setSelectedSite('demo')
    }
  }

  // 실시간 데이터 로드
  const loadRealData = async () => {
    if (!selectedSite) return
    
    try {
      setLoading(true)
      setApiError(null)
      
      const timeRange = createTimeRange(params.horizonHours)
      const [loadData, pvData] = await Promise.all([
        api.ds.getLoadData({ ...timeRange, siteId: selectedSite, interval: `${params.stepMinutes}min` }),
        api.ds.getPVData({ ...timeRange, siteId: selectedSite, interval: `${params.stepMinutes}min` })
      ])

      // 데이터 변환
      if (loadData.data && Array.isArray(loadData.data)) {
        const points = loadData.data.map((item, i) => ({
          ts: i,
          value: item.value || item.load_kw || 0
        }))
        setDemandCSV({ points, source: 'api' })
      }

      setUseRealData(true)
    } catch (err) {
      const error = handleApiError(err)
      setApiError(error)
      setUseRealData(false)
    } finally {
      setLoading(false)
    }
  }

  const steps = useMemo(() => Math.floor((params.horizonHours * 60) / params.stepMinutes), [params])
  const deltaH = useMemo(() => params.stepMinutes / 60, [params])

  const synthLoad = useMemo(() => {
    if (demandCSV?.points?.length > 0) {
      const pts = demandCSV.points
      const arr = []
      for (let i=0; i<Math.min(steps, pts.length); i++) arr.push(Math.max(0, Number(pts[i].value)||0))
      while (arr.length < steps) arr.push(arr[arr.length-1]||0)
      return arr
    }
    const arr = []
    for (let i = 0; i < steps; i++) {
      const tH = i * deltaH
      const hour = Math.floor(tH % 24)
      let val = params.loadBaseKw
      if (hour >= 7 && hour <= 10) val += params.loadMorningPeakKw * Math.sin(((hour - 7) / 3) * Math.PI)
      if (hour >= 18 && hour <= 22) val += params.loadEveningPeakKw * Math.sin(((hour - 18) / 4) * Math.PI)
      const day = Math.floor(tH / 24) % 7
      if (day === 6 || day === 0) val *= 0.9
      const noise = 1 + (Math.random() * 2 - 1) * (params.loadNoisePct / 100)
      arr.push(Math.max(0, val * noise))
    }
    return arr
  }, [steps, deltaH, params, demandCSV])

  const synthPV = useMemo(() => {
    const arr = []
    for (let i = 0; i < steps; i++) {
      const tH = i * deltaH
      const hour = tH % 24
      let cf = 0
      if (hour >= 6 && hour <= 18) {
        const x = (hour - 6) / 12
        cf = Math.sin(Math.PI * x)
      }
      const day = Math.floor(tH / 24)
      const dailyWeather = 1 - (params.pvWeatherPct / 100) * (0.5 - Math.sin(day * 1.3) * 0.5)
      const pvKw = Math.max(0, params.pvKwDc * cf * dailyWeather)
      arr.push(pvKw)
    }
    return arr
  }, [steps, deltaH, params])

  const priceAtHour = (h) => {
    const inPeak1 = h >= params.peakStart && h < params.peakEnd
    const inPeak2 = h >= params.peak2Start && h < params.peak2End
    return (inPeak1 || inPeak2) ? params.pricePeak : params.priceOff
  }

  function runEngine(conf) {
    const D = synthLoad
    const S = synthPV.map(v => v * (conf.pvScale ?? 1))
    const n = D.length, dt = deltaH
    const hasBatt = (conf.battCapacityKwh ?? params.battCapacityKwh) > 0

    const eta_rt = clamp((conf.battRtEff ?? params.battRtEff)/100, 0.5, 1.0)
    const eta_c = Math.sqrt(eta_rt), eta_d = Math.sqrt(eta_rt)
    const C = conf.battCapacityKwh ?? params.battCapacityKwh
    const socMin = (conf.battSocMinPct ?? params.battSocMinPct) / 100 * C
    const socMax = (conf.battSocMaxPct ?? params.battSocMaxPct) / 100 * C
    const pchgMax = conf.battPchgKw ?? params.battPchgKw
    const pdisMax = conf.battPdisKw ?? params.battPdisKw

    const ts = []
    let soc = socMin
    let eDemand=0, eOnsiteUsed=0, eOnsiteGen=0, sumImport=0, sumExport=0, sumCurtail=0, sumDischarge=0
    let costImport=0, revenueExport=0, co2_kg=0

    for (let i=0;i<n;i++){
      const hour = Math.floor((i*dt) % 24)
      const price = priceAtHour(hour) // KRW/kWh
      const feedin = params.feedin       // KRW/kWh
      const co2factor = params.co2_g_per_kwh / 1000 // kg/kWh

      const load = D[i], pv = S[i]
      eDemand += load * dt
      eOnsiteGen += pv * dt

      const direct = Math.min(load, pv)
      let surplus = pv - direct
      let residualLoad = load - direct

      let pchg = 0, pdis = 0
      if (hasBatt) {
        // charge
        pchg = Math.min(surplus, pchgMax)
        const room = (socMax - soc) / (Math.max(eta_c,1e-6) * dt)
        pchg = Math.max(0, Math.min(pchg, room))
        soc = soc + eta_c * pchg * dt
        surplus = surplus - pchg

        // discharge
        pdis = Math.min(residualLoad, pdisMax)
        const avail = (soc - socMin) * Math.max(eta_d,1e-6) / dt
        pdis = Math.max(0, Math.min(pdis, avail))
        soc = soc - (pdis / Math.max(eta_d,1e-6)) * dt
        residualLoad = residualLoad - pdis
      }

      const gridImport = Math.max(0, residualLoad)
      const gridExport = Math.max(0, surplus)
      const curtail = 0

      sumImport += gridImport * dt
      sumExport += gridExport * dt
      sumCurtail += curtail * dt
      eOnsiteUsed += (direct + pdis) * dt
      sumDischarge += pdis * dt

      costImport += gridImport * dt * price
      revenueExport += gridExport * dt * feedin
      co2_kg += gridImport * dt * co2factor

      ts.push({
        ts: i,
        load, pv, soc, import: gridImport, export: gridExport, pchg, pdis, price
      })
    }

    const matchRate = eDemand > 0 ? (eOnsiteUsed / eDemand) : 0
    const selfConsumption = eOnsiteGen > 0 ? (eOnsiteUsed / eOnsiteGen) : 0
    const selfSufficiency = matchRate
    const curtPct = eOnsiteGen > 0 ? (sumCurtail / eOnsiteGen) : 0

    const kpi = {
      demand_kwh: toFixed(eDemand),
      onsite_gen_kwh: toFixed(eOnsiteGen),
      onsite_used_kwh: toFixed(eOnsiteUsed),
      import_kwh: toFixed(sumImport),
      export_kwh: toFixed(sumExport),
      discharge_kwh: toFixed(sumDischarge),
      match_rate: toFixed(matchRate),
      self_consumption: toFixed(selfConsumption),
      self_sufficiency: toFixed(selfSufficiency),
      curtail_ratio: toFixed(curtPct),
      cost_import_krw: toFixed(costImport),
      revenue_export_krw: toFixed(revenueExport),
      net_cost_krw: toFixed(costImport - revenueExport),
      emissions_kg: toFixed(co2_kg),
    }

    return { ts, kpi }
  }

  // scenarios
  const scenarios = useMemo(() => {
    return [
      { key:'pv_only', name:'PV Only', conf: { pvScale: 1, battCapacityKwh: 0 } },
      { key:'pv_batt', name:'PV + Battery', conf: {} },
      { key:'mixed', name:'Mixed (PV120% + Batt150%)',
        conf: {
          pvScale: 1.2,
          battCapacityKwh: params.battCapacityKwh * 1.5,
          battPchgKw: params.battPchgKw * 1.2,
          battPdisKw: params.battPdisKw * 1.2
        } }
    ]
  }, [params])

  const runs = useMemo(() => {
    const out = {}
    scenarios.forEach(s => { out[s.key] = runEngine(s.conf) })
    return out
  }, [scenarios, synthLoad, synthPV, deltaH, params])

  // CSV upload handlers
  const onCSV = (file) => {
    if (!file) return
    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      skipEmptyLines: true,
      complete: (res) => {
        const rows = res.data
        // expected columns: ts, load_kw OR value
        const points = rows.map((r, i) => ({
          ts: r.ts ?? i,
          value: r.load_kw ?? r.value ?? r.load ?? 0
        }))
        setDemandCSV({ points })
      }
    })
  }
  const clearCSV = () => setDemandCSV(null)

  // Exports
  const chartRef = useRef(null)
  
  const saveSimulationResults = async () => {
    try {
      const results = {
        timestamp: new Date().toISOString(),
        siteId: selectedSite,
        params: params,
        scenarios: Object.entries(runs).map(([key, value]) => ({
          name: key,
          kpi: value.kpi,
          timeseries: value.ts
        }))
      }
      
      await api.sa.saveResults(results)
      alert('시뮬레이션 결과가 저장되었습니다.')
    } catch (err) {
      console.error('Failed to save results:', err)
      alert('결과 저장에 실패했습니다: ' + err.message)
    }
  }

  const downloadKPIs = () => {
    const rows = Object.entries(runs).map(([k,v]) => ({ scenario: k, ...v.kpi }))
    const csv = toCSV(rows)
    downloadBlob('kpi_scenarios.csv', new Blob([csv], { type:'text/csv' }))
    downloadBlob('kpi_scenarios.json', new Blob([JSON.stringify(rows, null, 2)], { type:'application/json' }))
  }
  const downloadTimeseries = () => {
    const cur = runs['pv_batt'] || Object.values(runs)[0]
    const csv = toCSV(cur.ts)
    downloadBlob('timeseries_current.csv', new Blob([csv], { type:'text/csv' }))
    downloadBlob('timeseries_current.json', new Blob([JSON.stringify(cur.ts, null, 2)], { type:'application/json' }))
  }
  const downloadPNG = async () => {
    if (!chartRef.current) return
    const canvas = await html2canvas(chartRef.current)
    canvas.toBlob((blob)=> downloadBlob('charts.png', blob))
  }

  const set = (patch) => setParams(p => ({ ...p, ...patch }))

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">수요–공급 매칭 시뮬레이터</h2>

      {/* API 연동 섹션 */}
      <div className="mb-6 border rounded-2xl p-4 shadow-soft bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            <h3 className="font-semibold">실시간 데이터 연동</h3>
          </div>
          <div className="flex items-center gap-2">
            {useRealData && (
              <span className="text-xs px-2 py-1 bg-green-100 text-green-700 rounded-lg flex items-center gap-1">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                실시간 데이터 사용 중
              </span>
            )}
          </div>
        </div>
        
        <div className="grid md:grid-cols-3 gap-3">
          <div>
            <label className="text-sm text-gray-600 mb-1 block">사이트 선택</label>
            <select 
              value={selectedSite || ''} 
              onChange={(e) => setSelectedSite(e.target.value)}
              className="w-full px-3 py-2 border rounded-xl bg-white dark:bg-gray-800"
              disabled={loading}
            >
              {sites.map(site => (
                <option key={site.id} value={site.id}>{site.name}</option>
              ))}
            </select>
          </div>
          
          <div className="flex items-end">
            <button 
              onClick={loadRealData}
              disabled={loading || !selectedSite}
              className="w-full px-4 py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  로딩 중...
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  실시간 데이터 불러오기
                </>
              )}
            </button>
          </div>

          <div className="flex items-end">
            <button 
              onClick={() => { setUseRealData(false); setDemandCSV(null); setApiError(null); }}
              className="w-full px-4 py-2 rounded-xl border border-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
            >
              합성 데이터 사용
            </button>
          </div>
        </div>

        {apiError && (
          <div className="mt-3 text-sm text-red-600 bg-red-50 dark:bg-red-900/20 p-3 rounded-lg">
            ⚠️ {apiError.message}
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="grid xl:grid-cols-4 md:grid-cols-2 gap-4">
        <Panel title="범위">
          <Field label="기간(시간)" type="number" value={params.horizonHours} onChange={v=>set({horizonHours: Number(v)||1})}/>
          <Field label="스텝(분)" type="number" value={params.stepMinutes} onChange={v=>set({stepMinutes: Number(v)||15})}/>
        </Panel>
        <Panel title="부하(Load)">
          <Field label="CSV 업로드(ts,value|load_kw)" type="file" onFile={onCSV} />
          <div className="flex items-center gap-2">
            <button className="px-3 py-1 border rounded-xl" onClick={clearCSV}>CSV 해제</button>
            <span className="text-xs text-gray-500">{demandCSV ? 'CSV 사용중' : '합성 부하 사용'}</span>
          </div>
          <Field label="평균 부하(kW)" type="number" value={params.loadBaseKw} onChange={v=>set({loadBaseKw:Number(v)||0})}/>
          <Field label="오전 피크(kW)" type="number" value={params.loadMorningPeakKw} onChange={v=>set({loadMorningPeakKw:Number(v)||0})}/>
          <Field label="저녁 피크(kW)" type="number" value={params.loadEveningPeakKw} onChange={v=>set({loadEveningPeakKw:Number(v)||0})}/>
          <Field label="노이즈(%)" type="number" value={params.loadNoisePct} onChange={v=>set({loadNoisePct:Number(v)||0})}/>
        </Panel>
        <Panel title="PV">
          <Field label="용량 kWdc" type="number" value={params.pvKwDc} onChange={v=>set({pvKwDc:Number(v)||0})}/>
          <Field label="날씨 변동(%)" type="number" value={params.pvWeatherPct} onChange={v=>set({pvWeatherPct:Number(v)||0})}/>
        </Panel>
        <Panel title="배터리">
          <Field label="용량(kWh)" type="number" value={params.battCapacityKwh} onChange={v=>set({battCapacityKwh:Number(v)||0})}/>
          <Field label="충전 최대(kW)" type="number" value={params.battPchgKw} onChange={v=>set({battPchgKw:Number(v)||0})}/>
          <Field label="방전 최대(kW)" type="number" value={params.battPdisKw} onChange={v=>set({battPdisKw:Number(v)||0})}/>
          <Field label="왕복 효율(%)" type="number" value={params.battRtEff} onChange={v=>set({battRtEff:Number(v)||0})}/>
          <Field label="SOC 최소(%)" type="number" value={params.battSocMinPct} onChange={v=>set({battSocMinPct:Number(v)||0})}/>
          <Field label="SOC 최대(%)" type="number" value={params.battSocMaxPct} onChange={v=>set({battSocMaxPct:Number(v)||0})}/>
        </Panel>
      </div>

      {/* Tariff / CO2 */}
      <div className="grid md:grid-cols-2 gap-4 mt-4">
        <Panel title="요금(TOU)">
          <div className="grid grid-cols-2 gap-2">
            <Field label="피크 시작(시)" type="number" value={params.peakStart} onChange={v=>set({peakStart:Number(v)||0})}/>
            <Field label="피크 종료(시)" type="number" value={params.peakEnd} onChange={v=>set({peakEnd:Number(v)||0})}/>
            <Field label="피크2 시작" type="number" value={params.peak2Start} onChange={v=>set({peak2Start:Number(v)||0})}/>
            <Field label="피크2 종료" type="number" value={params.peak2End} onChange={v=>set({peak2End:Number(v)||0})}/>
            <Field label="피크 단가(₩/kWh)" type="number" value={params.pricePeak} onChange={v=>set({pricePeak:Number(v)||0})}/>
            <Field label="오프피크 단가" type="number" value={params.priceOff} onChange={v=>set({priceOff:Number(v)||0})}/>
            <Field label="수출단가(피딘)" type="number" value={params.feedin} onChange={v=>set({feedin:Number(v)||0})}/>
          </div>
        </Panel>
        <Panel title="배출계수">
          <Field label="Grid CO₂ (g/kWh)" type="number" value={params.co2_g_per_kwh} onChange={v=>set({co2_g_per_kwh:Number(v)||0})}/>
          <div className="text-xs text-gray-500 mt-2">※ 수입전력량 × 배출계수로 총 배출량(kg)을 계산합니다.</div>
        </Panel>
      </div>

      {/* KPI & Scenarios */}
      <div className="mt-6">
        <h3 className="font-semibold mb-4 text-lg">시나리오 KPI 비교</h3>
        
        {/* Scenario Cards with Enhanced Visuals */}
        <div className="grid lg:grid-cols-3 gap-6">
          {Object.entries(runs).map(([key, v]) => {
            const scenario = scenarios.find(s => s.key === key)
            return (
              <div key={key} className="border rounded-2xl p-6 shadow-soft hover:shadow-lg transition-shadow bg-gradient-to-br from-white to-gray-50 dark:from-gray-800 dark:to-gray-900">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <div className="text-xs text-gray-500 uppercase tracking-wide">시나리오</div>
                    <div className="font-bold text-lg">{scenario?.name || key}</div>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${key === 'pv_only' ? 'bg-yellow-500' : key === 'pv_batt' ? 'bg-green-500' : 'bg-blue-500'}`} />
                </div>

                {/* Mini Performance Gauges */}
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="text-center">
                    <CircularGauge
                      value={v.kpi.match_rate * 100}
                      max={100}
                      label=""
                      unit="%"
                      color={key === 'pv_only' ? 'yellow' : key === 'pv_batt' ? 'green' : 'blue'}
                    />
                    <div className="text-xs text-gray-500 mt-1">자급률</div>
                  </div>
                  <div className="text-center">
                    <CircularGauge
                      value={v.kpi.self_consumption * 100}
                      max={100}
                      label=""
                      unit="%"
                      color="green"
                    />
                    <div className="text-xs text-gray-500 mt-1">자가소비</div>
                  </div>
                  <div className="text-center">
                    <CircularGauge
                      value={(v.kpi.import_kwh / v.kpi.demand_kwh) * 100}
                      max={100}
                      label=""
                      unit="%"
                      color="purple"
                    />
                    <div className="text-xs text-gray-500 mt-1">계통의존</div>
                  </div>
                </div>

                {/* Detailed KPIs */}
                <div className="border-t pt-4">
                  <KPIGrid kpi={v.kpi} />
                </div>

                {/* Energy Bars */}
                <div className="mt-4 space-y-2">
                  <HorizontalBar
                    label="총 수요"
                    value={v.kpi.demand_kwh}
                    max={Math.max(...Object.values(runs).map(r => r.kpi.demand_kwh))}
                    unit="kWh"
                    color="blue"
                  />
                  <HorizontalBar
                    label="태양광 발전"
                    value={v.kpi.onsite_gen_kwh}
                    max={Math.max(...Object.values(runs).map(r => r.kpi.onsite_gen_kwh))}
                    unit="kWh"
                    color="yellow"
                  />
                  <HorizontalBar
                    label="계통 수입"
                    value={v.kpi.import_kwh}
                    max={Math.max(...Object.values(runs).map(r => r.kpi.import_kwh))}
                    unit="kWh"
                    color="purple"
                  />
                </div>

                {/* Cost Summary */}
                <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-800 rounded-xl">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">전기요금</span>
                    <span className="font-semibold">₩{v.kpi.net_cost_krw.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">CO₂ 배출</span>
                    <span className="font-semibold">{v.kpi.emissions_kg.toFixed(1)} kg</span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Scenario Comparison Summary */}
        <div className="mt-6 grid md:grid-cols-2 gap-6">
          <ComparisonCard
            title="시나리오별 비용 비교"
            items={Object.entries(runs).map(([key, v]) => ({
              label: scenarios.find(s => s.key === key)?.name || key,
              value: `₩${(v.kpi.net_cost_krw / 1000).toFixed(1)}K`,
              unit: '',
              color: key === 'pv_only' ? 'bg-yellow-500' : key === 'pv_batt' ? 'bg-green-500' : 'bg-blue-500'
            }))}
          />
          <ComparisonCard
            title="시나리오별 CO₂ 배출"
            items={Object.entries(runs).map(([key, v]) => ({
              label: scenarios.find(s => s.key === key)?.name || key,
              value: v.kpi.emissions_kg.toFixed(1),
              unit: 'kg',
              color: key === 'pv_only' ? 'bg-yellow-500' : key === 'pv_batt' ? 'bg-green-500' : 'bg-blue-500'
            }))}
          />
        </div>
      </div>

      {/* Charts */}
      <div className="mt-6" ref={chartRef}>
        <div className="grid md:grid-cols-2 gap-4">
          <ChartCard title="수요·PV·수입/수출(kW) - PV+Battery">
            <TimeseriesChart
              data={runs['pv_batt']?.ts ?? []}
              series={[
                { dataKey: 'load', name: 'Load' },
                { dataKey: 'pv', name: 'PV' },
                { dataKey: 'import', name: 'Import' },
                { dataKey: 'export', name: 'Export' },
              ]}
            />
          </ChartCard>
          <ChartCard title="SOC / 충·방전 - PV+Battery">
            <TimeseriesChart
              data={runs['pv_batt']?.ts ?? []}
              series={[
                { dataKey: 'soc', name: 'SOC' },
                { dataKey: 'pchg', name: 'Pchg' },
                { dataKey: 'pdis', name: 'Pdis' },
              ]}
            />
          </ChartCard>
        </div>
      </div>

      {/* Exports */}
      <div className="mt-6 border-t pt-6">
        <h3 className="font-semibold mb-4">결과 내보내기 및 저장</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="text-sm text-gray-600 mb-2">로컬 다운로드</div>
            <button className="w-full px-4 py-2 rounded-xl bg-black text-white hover:bg-gray-800 transition-colors flex items-center justify-center gap-2" onClick={downloadKPIs}>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
              KPI CSV/JSON 다운로드
            </button>
            <button className="w-full px-4 py-2 rounded-xl bg-black text-white hover:bg-gray-800 transition-colors flex items-center justify-center gap-2" onClick={downloadTimeseries}>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" /></svg>
              시계열 CSV/JSON 다운로드
            </button>
            <button className="w-full px-4 py-2 rounded-xl bg-black text-white hover:bg-gray-800 transition-colors flex items-center justify-center gap-2" onClick={downloadPNG}>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
              차트 PNG 캡처
            </button>
          </div>
          <div className="space-y-2">
            <div className="text-sm text-gray-600 mb-2">클라우드 저장</div>
            <button 
              className="w-full px-4 py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition-colors flex items-center justify-center gap-2" 
              onClick={saveSimulationResults}
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
              시뮬레이션 결과 저장 (SA API)
            </button>
            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl text-sm">
              <div className="font-medium text-blue-900 dark:text-blue-300 mb-1">💡 클라우드 저장</div>
              <div className="text-blue-700 dark:text-blue-400">
                agent.gngmeta.com/sa API에 시뮬레이션 결과를 저장하여 나중에 분석하고 비교할 수 있습니다.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function Panel({ title, children }) {
  return (
    <div className="border rounded-2xl p-4 shadow-soft">
      <div className="text-sm font-medium mb-3">{title}</div>
      <div className="grid gap-3">{children}</div>
    </div>
  )
}
function Field({ label, type='text', value, onChange, onFile }) {
  if (type === 'file') {
    return (
      <label className="text-sm">
        <div className="mb-1 text-gray-600">{label}</div>
        <input className="w-full" type="file" accept=".csv,text/csv"
          onChange={(e)=>onFile && onFile(e.target.files[0])} />
      </label>
    )
  }
  return (
    <label className="text-sm">
      <div className="mb-1 text-gray-600">{label}</div>
      <input
        className="w-full border rounded-xl px-3 py-2 bg-transparent"
        type={type}
        value={value}
        onChange={(e)=>onChange && onChange(e.target.value)}
      />
    </label>
  )
}
function ChartCard({ title, children }) {
  return (
    <div className="border rounded-2xl p-4 shadow-soft">
      <div className="text-sm text-gray-600 mb-2">{title}</div>
      {children}
    </div>
  )
}
