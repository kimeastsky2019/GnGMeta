import React, { useEffect, useMemo, useRef, useState } from 'react'
import { api, createTimeRange } from '../lib/api'
import { MetricCard, ComparisonCard, StatsGrid } from '../components/Infographic'
import KPIGrid from '../components/KPIGrid'
import TimeseriesChart from '../components/TimeseriesChart'
import Papa from 'papaparse'
import html2canvas from 'html2canvas'
import { saveJSON, loadJSON, downloadBlob, toCSV } from '../lib/storage'

const clamp = (v, a, b) => Math.max(a, Math.min(b, v))
const toFixed = (n) => (typeof n === 'number' ? Number(n.toFixed(3)) : n)

const LS_KEY = 'ng.sim.params.v2'
const LS_DEMAND = 'ng.sim.demand.v2'

export default function SimulatorEnhanced() {
  const [params, setParams] = useState(() => loadJSON(LS_KEY, {
    horizonHours: 24 * 7,
    stepMinutes: 15,
    loadBaseKw: 80,
    loadMorningPeakKw: 30,
    loadEveningPeakKw: 40,
    loadNoisePct: 5,
    pvKwDc: 120,
    pvWeatherPct: 15,
    battCapacityKwh: 300,
    battPchgKw: 100,
    battPdisKw: 100,
    battRtEff: 92,
    battSocMinPct: 10,
    battSocMaxPct: 90,
    peakStart: 9, peakEnd: 12, peak2Start: 18, peak2End: 21,
    pricePeak: 220, priceOff: 110, feedin: 60, co2_g_per_kwh: 450,
  }))
  
  const [demandCSV, setDemandCSV] = useState(()=> loadJSON(LS_DEMAND, null))
  const [useRealData, setUseRealData] = useState(false)
  const [realTimeLoad, setRealTimeLoad] = useState(null)
  const [realTimePV, setRealTimePV] = useState(null)
  const [apiLoading, setApiLoading] = useState(false)
  const [savedResults, setSavedResults] = useState([])

  useEffect(()=> saveJSON(LS_KEY, params), [params])
  useEffect(()=> saveJSON(LS_DEMAND, demandCSV), [demandCSV])

  // API에서 실시간 데이터 가져오기
  const loadRealTimeData = async () => {
    setApiLoading(true)
    try {
      const timeRange = createTimeRange(params.horizonHours)
      const [loadData, pvData] = await Promise.all([
        api.ds.getLoadData({ ...timeRange, interval: `${params.stepMinutes}min` }),
        api.ds.getPVData({ ...timeRange, interval: `${params.stepMinutes}min` }),
      ])
      
      setRealTimeLoad(loadData)
      setRealTimePV(pvData)
      setUseRealData(true)
    } catch (error) {
      console.error('Failed to load real-time data:', error)
      alert('실시간 데이터를 불러오는데 실패했습니다. 합성 데이터를 사용합니다.')
      setUseRealData(false)
    } finally {
      setApiLoading(false)
    }
  }

  // 과거 시뮬레이션 결과 불러오기
  const loadSavedResults = async () => {
    try {
      const results = await api.sa.getResults({ limit: 5 })
      setSavedResults(results.data || [])
    } catch (error) {
      console.error('Failed to load saved results:', error)
    }
  }

  useEffect(() => {
    loadSavedResults()
  }, [])

  const steps = useMemo(() => Math.floor((params.horizonHours * 60) / params.stepMinutes), [params])
  const deltaH = useMemo(() => params.stepMinutes / 60, [params])

  const synthLoad = useMemo(() => {
    // 실시간 데이터 사용
    if (useRealData && realTimeLoad?.data) {
      const arr = []
      for (let i=0; i<Math.min(steps, realTimeLoad.data.length); i++) {
        arr.push(Math.max(0, realTimeLoad.data[i]?.value || 0))
      }
      while (arr.length < steps) arr.push(arr[arr.length-1]||0)
      return arr
    }
    
    // CSV 데이터 사용
    if (demandCSV?.points?.length > 0) {
      const pts = demandCSV.points
      const arr = []
      for (let i=0; i<Math.min(steps, pts.length); i++) arr.push(Math.max(0, Number(pts[i].value)||0))
      while (arr.length < steps) arr.push(arr[arr.length-1]||0)
      return arr
    }
    
    // 합성 데이터 생성
    const arr = []
    for (let i = 0; i < steps; i++) {
      const tH = i * deltaH
      const hour = Math.floor(tH % 24)
      let val = params.loadBaseKw
      if (hour >= 7 && hour <= 10) val += params.loadMorningPeakKw * Math.sin(((hour - 7) / 3) * Math.PI)
      if (hour >= 18 && hour <= 22) val += params.loadEveningPeakKw * Math.sin(((hour - 18) / 4) * Math.PI)
      const day = Math.floor(tH / 24) % 7
      if (day === 6 || day === 0) val *= 0.9
      const noise = 1 + (Math.random() * 2 - 1) * (params.loadNoisePct / 100)
      arr.push(Math.max(0, val * noise))
    }
    return arr
  }, [steps, deltaH, params, demandCSV, useRealData, realTimeLoad])

  const synthPV = useMemo(() => {
    // 실시간 PV 데이터 사용
    if (useRealData && realTimePV?.data) {
      const arr = []
      for (let i=0; i<Math.min(steps, realTimePV.data.length); i++) {
        arr.push(Math.max(0, realTimePV.data[i]?.value || 0))
      }
      while (arr.length < steps) arr.push(arr[arr.length-1]||0)
      return arr
    }

    // 합성 PV 데이터 생성
    const arr = []
    for (let i = 0; i < steps; i++) {
      const tH = i * deltaH
      const hour = tH % 24
      let cf = 0
      if (hour >= 6 && hour <= 18) {
        const x = (hour - 6) / 12
        cf = Math.sin(Math.PI * x)
      }
      const day = Math.floor(tH / 24)
      const dailyWeather = 1 - (params.pvWeatherPct / 100) * (0.5 - Math.sin(day * 1.3) * 0.5)
      const pvKw = Math.max(0, params.pvKwDc * cf * dailyWeather)
      arr.push(pvKw)
    }
    return arr
  }, [steps, deltaH, params, useRealData, realTimePV])

  const priceAtHour = (h) => {
    const inPeak1 = h >= params.peakStart && h < params.peakEnd
    const inPeak2 = h >= params.peak2Start && h < params.peak2End
    return (inPeak1 || inPeak2) ? params.pricePeak : params.priceOff
  }

  function runEngine(conf) {
    const D = synthLoad
    const S = synthPV.map(v => v * (conf.pvScale ?? 1))
    const n = D.length, dt = deltaH
    const hasBatt = (conf.battCapacityKwh ?? params.battCapacityKwh) > 0

    const eta_rt = clamp((conf.battRtEff ?? params.battRtEff)/100, 0.5, 1.0)
    const eta_c = Math.sqrt(eta_rt), eta_d = Math.sqrt(eta_rt)
    const C = conf.battCapacityKwh ?? params.battCapacityKwh
    const socMin = (conf.battSocMinPct ?? params.battSocMinPct) / 100 * C
    const socMax = (conf.battSocMaxPct ?? params.battSocMaxPct) / 100 * C
    const pchgMax = conf.battPchgKw ?? params.battPchgKw
    const pdisMax = conf.battPdisKw ?? params.battPdisKw

    const ts = []
    let soc = socMin
    let eDemand=0, eOnsiteUsed=0, eOnsiteGen=0, sumImport=0, sumExport=0, sumCurtail=0, sumDischarge=0
    let costImport=0, revenueExport=0, co2_kg=0

    for (let i=0;i<n;i++){
      const hour = Math.floor((i*dt) % 24)
      const price = priceAtHour(hour)
      const feedin = params.feedin
      const co2factor = params.co2_g_per_kwh / 1000

      const load = D[i], pv = S[i]
      eDemand += load * dt
      eOnsiteGen += pv * dt

      const direct = Math.min(load, pv)
      let surplus = pv - direct
      let residualLoad = load - direct

      let pchg = 0, pdis = 0
      if (hasBatt) {
        pchg = Math.min(surplus, pchgMax)
        const room = (socMax - soc) / (Math.max(eta_c,1e-6) * dt)
        pchg = Math.max(0, Math.min(pchg, room))
        soc = soc + eta_c * pchg * dt
        surplus = surplus - pchg

        pdis = Math.min(residualLoad, pdisMax)
        const avail = (soc - socMin) * Math.max(eta_d,1e-6) / dt
        pdis = Math.max(0, Math.min(pdis, avail))
        soc = soc - (pdis / Math.max(eta_d,1e-6)) * dt
        residualLoad = residualLoad - pdis
      }

      const gridImport = Math.max(0, residualLoad)
      const gridExport = Math.max(0, surplus)
      const curtail = 0

      sumImport += gridImport * dt
      sumExport += gridExport * dt
      sumCurtail += curtail * dt
      eOnsiteUsed += (direct + pdis) * dt
      sumDischarge += pdis * dt

      costImport += gridImport * dt * price
      revenueExport += gridExport * dt * feedin
      co2_kg += gridImport * dt * co2factor

      ts.push({
        ts: i,
        load, pv, soc, import: gridImport, export: gridExport, pchg, pdis, price
      })
    }

    const matchRate = eDemand > 0 ? (eOnsiteUsed / eDemand) : 0
    const selfConsumption = eOnsiteGen > 0 ? (eOnsiteUsed / eOnsiteGen) : 0
    const selfSufficiency = matchRate
    const curtPct = eOnsiteGen > 0 ? (sumCurtail / eOnsiteGen) : 0

    const kpi = {
      demand_kwh: toFixed(eDemand),
      onsite_gen_kwh: toFixed(eOnsiteGen),
      onsite_used_kwh: toFixed(eOnsiteUsed),
      import_kwh: toFixed(sumImport),
      export_kwh: toFixed(sumExport),
      discharge_kwh: toFixed(sumDischarge),
      match_rate: toFixed(matchRate),
      self_consumption: toFixed(selfConsumption),
      self_sufficiency: toFixed(selfSufficiency),
      curtail_ratio: toFixed(curtPct),
      cost_import_krw: toFixed(costImport),
      revenue_export_krw: toFixed(revenueExport),
      net_cost_krw: toFixed(costImport - revenueExport),
      emissions_kg: toFixed(co2_kg),
    }

    return { ts, kpi }
  }

  const scenarios = useMemo(() => {
    return [
      { key:'baseline', name:'기준선 (PV Only)', conf: { pvScale: 1, battCapacityKwh: 0 } },
      { key:'current', name:'현재 시스템', conf: {} },
      { key:'optimized', name:'최적화 시나리오',
        conf: {
          pvScale: 1.2,
          battCapacityKwh: params.battCapacityKwh * 1.5,
          battPchgKw: params.battPchgKw * 1.2,
          battPdisKw: params.battPdisKw * 1.2
        } }
    ]
  }, [params])

  const runs = useMemo(() => {
    const out = {}
    scenarios.forEach(s => { out[s.key] = runEngine(s.conf) })
    return out
  }, [scenarios, synthLoad, synthPV, deltaH, params])

  // API로 시뮬레이션 결과 저장
  const saveToAPI = async () => {
    try {
      const results = {
        params,
        scenarios: Object.entries(runs).map(([key, value]) => ({
          scenario: key,
          kpi: value.kpi,
        })),
        timestamp: new Date().toISOString(),
      }
      
      await api.sa.saveResults(results)
      alert('시뮬레이션 결과가 저장되었습니다!')
      loadSavedResults()
    } catch (error) {
      console.error('Failed to save results:', error)
      alert('결과 저장에 실패했습니다.')
    }
  }

  // CSV 핸들러
  const onCSV = (file) => {
    if (!file) return
    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      skipEmptyLines: true,
      complete: (res) => {
        const rows = res.data
        const points = rows.map((r, i) => ({
          ts: r.ts ?? i,
          value: r.load_kw ?? r.value ?? r.load ?? 0
        }))
        setDemandCSV({ points })
        setUseRealData(false)
      }
    })
  }
  const clearCSV = () => {
    setDemandCSV(null)
    setUseRealData(false)
  }

  // Export 함수들
  const chartRef = useRef(null)
  const downloadKPIs = () => {
    const rows = Object.entries(runs).map(([k,v]) => ({ scenario: k, ...v.kpi }))
    const csv = toCSV(rows)
    downloadBlob('kpi_scenarios.csv', new Blob([csv], { type:'text/csv' }))
    downloadBlob('kpi_scenarios.json', new Blob([JSON.stringify(rows, null, 2)], { type:'application/json' }))
  }
  const downloadTimeseries = () => {
    const cur = runs['current'] || Object.values(runs)[0]
    const csv = toCSV(cur.ts)
    downloadBlob('timeseries_current.csv', new Blob([csv], { type:'text/csv' }))
    downloadBlob('timeseries_current.json', new Blob([JSON.stringify(cur.ts, null, 2)], { type:'application/json' }))
  }
  const downloadPNG = async () => {
    if (!chartRef.current) return
    const canvas = await html2canvas(chartRef.current)
    canvas.toBlob((blob)=> downloadBlob('charts.png', blob))
  }

  const set = (patch) => setParams(p => ({ ...p, ...patch }))

  // 시나리오 비교 데이터
  const comparisonData = useMemo(() => {
    const baseline = runs['baseline']?.kpi
    const current = runs['current']?.kpi
    const optimized = runs['optimized']?.kpi

    return [
      {
        label: '자급률',
        baseline: ((baseline?.self_sufficiency || 0) * 100).toFixed(1),
        current: ((current?.self_sufficiency || 0) * 100).toFixed(1),
        optimized: ((optimized?.self_sufficiency || 0) * 100).toFixed(1),
        unit: '%'
      },
      {
        label: '순비용',
        baseline: (baseline?.net_cost_krw || 0).toFixed(0),
        current: (current?.net_cost_krw || 0).toFixed(0),
        optimized: (optimized?.net_cost_krw || 0).toFixed(0),
        unit: '원'
      },
      {
        label: 'CO₂ 배출',
        baseline: (baseline?.emissions_kg || 0).toFixed(1),
        current: (current?.emissions_kg || 0).toFixed(1),
        optimized: (optimized?.emissions_kg || 0).toFixed(1),
        unit: 'kg'
      },
    ]
  }, [runs])

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">에너지 시뮬레이터</h2>

      {/* 데이터 소스 선택 */}
      <div className="rounded-2xl border border-blue-200 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-800 p-6">
        <h3 className="font-semibold mb-4">데이터 소스</h3>
        <div className="flex flex-wrap gap-3">
          <button
            onClick={loadRealTimeData}
            disabled={apiLoading}
            className="px-4 py-2 rounded-xl bg-blue-500 text-white hover:bg-blue-600 disabled:opacity-50 transition-colors"
          >
            {apiLoading ? '로딩 중...' : 'API에서 실시간 데이터 가져오기'}
          </button>
          <label className="px-4 py-2 rounded-xl bg-white border cursor-pointer hover:bg-gray-50 transition-colors">
            CSV 파일 업로드
            <input 
              type="file" 
              className="hidden" 
              accept=".csv,text/csv"
              onChange={(e)=>onCSV(e.target.files[0])} 
            />
          </label>
          <button
            onClick={clearCSV}
            className="px-4 py-2 rounded-xl border hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
          >
            합성 데이터 사용
          </button>
          <div className="ml-auto px-4 py-2 rounded-xl bg-gray-100 dark:bg-gray-800 text-sm">
            현재: {useRealData ? 'API 실시간' : demandCSV ? 'CSV 파일' : '합성 데이터'}
          </div>
        </div>
      </div>

      {/* 시나리오 비교 인포그래픽 */}
      <div className="grid md:grid-cols-3 gap-4">
        {scenarios.map(s => (
          <MetricCard
            key={s.key}
            title={s.name}
            value={(runs[s.key]?.kpi?.self_sufficiency * 100 || 0).toFixed(1)}
            unit="%"
            change={s.key === 'baseline' ? null : 
              (((runs[s.key]?.kpi?.self_sufficiency || 0) - (runs['baseline']?.kpi?.self_sufficiency || 0)) * 100).toFixed(1)
            }
            color={s.key === 'baseline' ? 'blue' : s.key === 'current' ? 'green' : 'purple'}
          />
        ))}
      </div>

      {/* 비교 테이블 */}
      <div className="rounded-2xl border bg-white p-6 shadow-soft dark:bg-gray-900 dark:border-gray-800">
        <h3 className="font-semibold mb-4">시나리오 비교</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4">지표</th>
                <th className="text-right py-3 px-4">기준선</th>
                <th className="text-right py-3 px-4">현재</th>
                <th className="text-right py-3 px-4">최적화</th>
              </tr>
            </thead>
            <tbody>
              {comparisonData.map((row, idx) => (
                <tr key={idx} className="border-b last:border-0">
                  <td className="py-3 px-4">{row.label}</td>
                  <td className="text-right py-3 px-4">{row.baseline} {row.unit}</td>
                  <td className="text-right py-3 px-4 font-medium">{row.current} {row.unit}</td>
                  <td className="text-right py-3 px-4 text-purple-600 font-medium">{row.optimized} {row.unit}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 파라미터 설정 */}
      <details className="rounded-2xl border bg-white p-6 shadow-soft dark:bg-gray-900 dark:border-gray-800">
        <summary className="font-semibold cursor-pointer">파라미터 설정</summary>
        <div className="grid xl:grid-cols-4 md:grid-cols-2 gap-4 mt-4">
          <Panel title="범위">
            <Field label="기간(시간)" type="number" value={params.horizonHours} onChange={v=>set({horizonHours: Number(v)||1})}/>
            <Field label="스텝(분)" type="number" value={params.stepMinutes} onChange={v=>set({stepMinutes: Number(v)||15})}/>
          </Panel>
          <Panel title="부하(Load)">
            <Field label="평균 부하(kW)" type="number" value={params.loadBaseKw} onChange={v=>set({loadBaseKw:Number(v)||0})}/>
            <Field label="오전 피크(kW)" type="number" value={params.loadMorningPeakKw} onChange={v=>set({loadMorningPeakKw:Number(v)||0})}/>
            <Field label="저녁 피크(kW)" type="number" value={params.loadEveningPeakKw} onChange={v=>set({loadEveningPeakKw:Number(v)||0})}/>
            <Field label="노이즈(%)" type="number" value={params.loadNoisePct} onChange={v=>set({loadNoisePct:Number(v)||0})}/>
          </Panel>
          <Panel title="PV">
            <Field label="용량 kWdc" type="number" value={params.pvKwDc} onChange={v=>set({pvKwDc:Number(v)||0})}/>
            <Field label="날씨 변동(%)" type="number" value={params.pvWeatherPct} onChange={v=>set({pvWeatherPct:Number(v)||0})}/>
          </Panel>
          <Panel title="배터리">
            <Field label="용량(kWh)" type="number" value={params.battCapacityKwh} onChange={v=>set({battCapacityKwh:Number(v)||0})}/>
            <Field label="충전 최대(kW)" type="number" value={params.battPchgKw} onChange={v=>set({battPchgKw:Number(v)||0})}/>
            <Field label="방전 최대(kW)" type="number" value={params.battPdisKw} onChange={v=>set({battPdisKw:Number(v)||0})}/>
            <Field label="왕복 효율(%)" type="number" value={params.battRtEff} onChange={v=>set({battRtEff:Number(v)||0})}/>
            <Field label="SOC 최소(%)" type="number" value={params.battSocMinPct} onChange={v=>set({battSocMinPct:Number(v)||0})}/>
            <Field label="SOC 최대(%)" type="number" value={params.battSocMaxPct} onChange={v=>set({battSocMaxPct:Number(v)||0})}/>
          </Panel>
        </div>

        <div className="grid md:grid-cols-2 gap-4 mt-4">
          <Panel title="요금(TOU)">
            <div className="grid grid-cols-2 gap-2">
              <Field label="피크 시작(시)" type="number" value={params.peakStart} onChange={v=>set({peakStart:Number(v)||0})}/>
              <Field label="피크 종료(시)" type="number" value={params.peakEnd} onChange={v=>set({peakEnd:Number(v)||0})}/>
              <Field label="피크2 시작" type="number" value={params.peak2Start} onChange={v=>set({peak2Start:Number(v)||0})}/>
              <Field label="피크2 종료" type="number" value={params.peak2End} onChange={v=>set({peak2End:Number(v)||0})}/>
              <Field label="피크 단가(₩/kWh)" type="number" value={params.pricePeak} onChange={v=>set({pricePeak:Number(v)||0})}/>
              <Field label="오프피크 단가" type="number" value={params.priceOff} onChange={v=>set({priceOff:Number(v)||0})}/>
              <Field label="수출단가(피딘)" type="number" value={params.feedin} onChange={v=>set({feedin:Number(v)||0})}/>
            </div>
          </Panel>
          <Panel title="배출계수">
            <Field label="Grid CO₂ (g/kWh)" type="number" value={params.co2_g_per_kwh} onChange={v=>set({co2_g_per_kwh:Number(v)||0})}/>
            <div className="text-xs text-gray-500 mt-2">※ 수입전력량 × 배출계수로 총 배출량(kg)을 계산합니다.</div>
          </Panel>
        </div>
      </details>

      {/* 차트 */}
      <div className="mt-6" ref={chartRef}>
        <div className="grid md:grid-cols-2 gap-4">
          <ChartCard title="전력 흐름 - 현재 시스템">
            <TimeseriesChart
              data={runs['current']?.ts ?? []}
              series={[
                { dataKey: 'load', name: 'Load', stroke: '#3b82f6' },
                { dataKey: 'pv', name: 'PV', stroke: '#f59e0b' },
                { dataKey: 'import', name: 'Import', stroke: '#ef4444' },
                { dataKey: 'export', name: 'Export', stroke: '#10b981' },
              ]}
            />
          </ChartCard>
          <ChartCard title="배터리 SOC / 충·방전">
            <TimeseriesChart
              data={runs['current']?.ts ?? []}
              series={[
                { dataKey: 'soc', name: 'SOC', stroke: '#8b5cf6' },
                { dataKey: 'pchg', name: 'Charge', stroke: '#06b6d4' },
                { dataKey: 'pdis', name: 'Discharge', stroke: '#f97316' },
              ]}
            />
          </ChartCard>
        </div>
      </div>

      {/* KPI 상세 */}
      <details className="rounded-2xl border bg-white p-6 shadow-soft dark:bg-gray-900 dark:border-gray-800">
        <summary className="font-semibold cursor-pointer mb-4">상세 KPI</summary>
        <div className="grid md:grid-cols-3 gap-4">
          {Object.entries(runs).map(([key, v]) => (
            <div key={key} className="border rounded-xl p-4">
              <div className="text-sm text-gray-600 mb-2">{scenarios.find(s => s.key === key)?.name}</div>
              <KPIGrid kpi={v.kpi} />
            </div>
          ))}
        </div>
      </details>

      {/* 액션 버튼 */}
      <div className="flex flex-wrap gap-3">
        <button 
          onClick={saveToAPI}
          className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600 text-white font-medium hover:shadow-lg transition-all"
        >
          결과 저장 (API)
        </button>
        <button 
          onClick={downloadKPIs}
          className="px-6 py-3 rounded-xl bg-black text-white hover:bg-gray-800 transition-colors"
        >
          KPI 다운로드
        </button>
        <button 
          onClick={downloadTimeseries}
          className="px-6 py-3 rounded-xl bg-black text-white hover:bg-gray-800 transition-colors"
        >
          시계열 다운로드
        </button>
        <button 
          onClick={downloadPNG}
          className="px-6 py-3 rounded-xl bg-black text-white hover:bg-gray-800 transition-colors"
        >
          차트 캡처
        </button>
      </div>

      {/* 과거 시뮬레이션 결과 */}
      {savedResults.length > 0 && (
        <details className="rounded-2xl border bg-white p-6 shadow-soft dark:bg-gray-900 dark:border-gray-800">
          <summary className="font-semibold cursor-pointer">저장된 시뮬레이션 결과</summary>
          <div className="mt-4 space-y-2">
            {savedResults.map((result, idx) => (
              <div key={idx} className="border rounded-xl p-4">
                <div className="text-sm text-gray-500">
                  {new Date(result.timestamp).toLocaleString('ko-KR')}
                </div>
                <div className="mt-2 text-sm">
                  {result.scenarios?.map((s, i) => (
                    <span key={i} className="mr-4">
                      {s.scenario}: {(s.kpi.self_sufficiency * 100).toFixed(1)}%
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </details>
      )}
    </div>
  )
}

function Panel({ title, children }) {
  return (
    <div className="border rounded-2xl p-4">
      <div className="text-sm font-medium mb-3">{title}</div>
      <div className="grid gap-3">{children}</div>
    </div>
  )
}

function Field({ label, type='text', value, onChange }) {
  return (
    <label className="text-sm">
      <div className="mb-1 text-gray-600 dark:text-gray-400">{label}</div>
      <input
        className="w-full border rounded-xl px-3 py-2 bg-white dark:bg-gray-800"
        type={type}
        value={value}
        onChange={(e)=>onChange && onChange(e.target.value)}
      />
    </label>
  )
}

function ChartCard({ title, children }) {
  return (
    <div className="border rounded-2xl p-4 bg-white dark:bg-gray-900 dark:border-gray-800 shadow-soft">
      <div className="text-sm font-medium mb-2">{title}</div>
      {children}
    </div>
  )
}
